import tkinter as tk
from tkinter import Message, Text
import cv2
import os
import shutil
import csv
import numpy as np
from PIL import Image, ImageTk
import pandas as pd
import datetime
import time
import tkinter.ttk as ttk
import tkinter.font as font
from urllib.request import urlopen
from ssl import SSLContext, PROTOCOL_TLSv1



window = tk.Tk()
window.title("Face_Recogniser attendance system")
dialog_title = 'QUIT'
window.geometry('1366x768')
window.configure(background='black')  # background='grey')
# window.configure(background='Red')

#window.attributes('-fullscreen', True)

window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)

# path = "im0.png"
path = "1.jpg"
path2 = "im1.jpg"
# Creates a Tkinter-compatible photo image, which can be used everywhere Tkinter expects an image object.
img = ImageTk.PhotoImage(Image.open(path))
#img2 = ImageTk.PhotoImage(Image.open(path2))
# The Label widget is a standard Tkinter widget used to display a text or image on the screen.
panel = tk.Label(window, image=img)

#panel2 = tk.Label(window, image=img2)
panel.pack(side="left", fill="x", expand="no")
#panel2.pack(side="right", fill="x", expand="no")
message = tk.Label(window, text="Face-Recognition-Attendance-System", bg="green",
                   fg="black", width=50, height=3, font=('arial', 30, 'italic bold underline'))

message.place(x=80, y=20)

lbl = tk.Label(window, text="EMP ID", width=20, height=2,
               fg="white", bg="green", font=('times', 15, ' bold '))
lbl.place(x=400, y=200)

txt = tk.Entry(window, width=20, bg="green",
               fg="white", font=('times', 15, ' bold '))
txt.place(x=700, y=215)

lbl2 = tk.Label(window, text="Employee Name", width=20, fg="white",
                bg="green", height=2, font=('times', 15, ' bold '))
lbl2.place(x=400, y=300)

txt2 = tk.Entry(window, width=20, bg="green",
                fg="white", font=('times', 15, ' bold '))
txt2.place(x=700, y=315)

lbl3 = tk.Label(window, text="Notification : ", width=20, fg="white",
                bg="green", height=2, font=('times', 15, ' bold underline '))
lbl3.place(x=400, y=400)

message = tk.Label(window, text="", bg="green", fg="white", width=30,
                   height=2, activebackground="yellow", font=('times', 15, ' bold '))
message.place(x=700, y=400)

lbl3 = tk.Label(window, text="Attendance : ", width=20, fg="white",
                bg="green", height=2, font=('times', 15, ' bold  underline'))
lbl3.place(x=400, y=600)


message2 = tk.Label(window, text="", fg="white", bg="green",
                    activeforeground="green", width=50, height=2, font=('times', 15, ' bold '))
message2.place(x=700, y=600)


def clear():
    txt.delete(0, 'end')
    res = ""
    message.configure(text=res)


def clear2():
    txt2.delete(0, 'end')
    res = ""
    message.configure(text=res)


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass

    return False


# def TakeImages():
#     Id = txt.get().strip()
#     name = txt2.get().strip()

#     if not is_number(Id):
#         message.configure(text="Enter Numeric Id")
#         return
#     if not name.isalpha():
#         message.configure(text="Enter Alphabetical Name")
#         return

#     # Use local webcam for testing; switch to IP cam when needed
#     ipcam = "http://192.168.1.4:8080/video"
#     cam = cv2.VideoCapture(ipcam)  # Use local webcam first for testing

#     if not cam.isOpened():
#         message.configure(text="Error: Cannot access camera!")
#         return

#     # Load Haarcascade face detection model
#     harcascadePath = "haarcascade_frontalface_default.xml"
#     if not os.path.exists(harcascadePath):
#         message.configure(text="Error: Haarcascade file not found!")
#         return

#     detector = cv2.CascadeClassifier(harcascadePath)

#     # Create TrainingImage directory if not exists
#     save_path = "TrainingImage"
#     if not os.path.exists(save_path):
#         os.makedirs(save_path)

#     sampleNum = 0
#     while True:
#         ret, img = cam.read()
#         if not ret:
#             print("Failed to grab frame. Check camera connection!")
#             break

#         gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#         faces = detector.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(30, 30))

#         print(f"Detected {len(faces)} face(s)")  # Debugging info

#         for (x, y, w, h) in faces:
#             cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
#             sampleNum += 1

#             # Save captured face images
#             image_path = os.path.join(save_path, f"{name}.{Id}.{sampleNum}.jpg")
#             cv2.imwrite(image_path, gray[y:y + h, x:x + w])

#             cv2.imshow('frame', img)

#         if cv2.waitKey(100) & 0xFF == ord('q'):
#             break
#         elif sampleNum >= 100:
#             break

#     cam.release()
#     cv2.destroyAllWindows()

#     # Ensure EmployeeDetails directory exists
#     csv_folder = "EmployeeDetails"
#     csv_file_path = os.path.join(csv_folder, "EmployeeDetails.csv")

#     if not os.path.exists(csv_folder):
#         os.makedirs(csv_folder)

#     # **🔹 Ensure 'Id' and 'Name' columns exist**
#     file_exists = os.path.isfile(csv_file_path)
#     with open(csv_file_path, 'a+', newline='') as csvFile:
#         writer = csv.writer(csvFile)

#         # **Write Header if File is Empty**
#         if not file_exists or os.stat(csv_file_path).st_size == 0:
#             writer.writerow(["Id", "Name"])

#         # **🔹 Prevent duplicate IDs**
#         csvFile.seek(0)  # Move cursor to start
#         existing_ids = [row[0] for row in csv.reader(csvFile)]

#         if Id not in existing_ids:
#             writer.writerow([Id, name])
#         else:
#             message.configure(text=f"ID {Id} already exists! Try another.")

#     message.configure(text=f"✅ Images Saved for ID: {Id}, Name: {name}")


def TakeImages():
    Id = txt.get().strip()
    name = txt2.get().strip()

    if not is_number(Id):
        message.configure(text="Enter Numeric Id")
        return
    if not name.isalpha():
        message.configure(text="Enter Alphabetical Name")
        return

    # Use local webcam for testing; switch to IP cam when needed
    ipcam = "http://192.168.1.4:8080/video"
    cam = cv2.VideoCapture(ipcam)  # Use local webcam first for testing

    if not cam.isOpened():
        message.configure(text="Error: Cannot access camera!")
        return

    # Load Haarcascade face detection model
    harcascadePath = "haarcascade_frontalface_default.xml"
    if not os.path.exists(harcascadePath):
        message.configure(text="Error: Haarcascade file not found!")
        return

    detector = cv2.CascadeClassifier(harcascadePath)

    # Create TrainingImage directory if not exists
    save_path = "TrainingImage"
    os.makedirs(save_path, exist_ok=True)

    sampleNum = 0
    while True:
        ret, img = cam.read()
        if not ret:
            print("Failed to grab frame. Check camera connection!")
            break

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(30, 30))

        print(f"Detected {len(faces)} face(s)")  # Debugging info

        for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
            sampleNum += 1

            # Save captured face images
            image_path = os.path.join(save_path, f"{name}.{Id}.{sampleNum}.jpg")
            cv2.imwrite(image_path, gray[y:y + h, x:x + w])

            cv2.imshow('frame', img)

        if cv2.waitKey(100) & 0xFF == ord('q'):
            break
        elif sampleNum >= 100:
            break

    cam.release()
    cv2.destroyAllWindows()

    # Ensure EmployeeDetails directory exists
    csv_folder = "EmployeeDetails"
    csv_file_path = os.path.join(csv_folder, "EmployeeDetails.csv")
    os.makedirs(csv_folder, exist_ok=True)

    # Read existing IDs safely
    existing_ids = set()
    if os.path.isfile(csv_file_path) and os.stat(csv_file_path).st_size > 0:
        with open(csv_file_path, 'r', newline='') as csvReadFile:
            reader = csv.reader(csvReadFile)
            next(reader, None)  # Skip header row
            existing_ids = {row[0] for row in reader if row}  # Use set for fast lookup

    # Append new ID if not duplicate
    with open(csv_file_path, 'a+', newline='') as csvFile:
        writer = csv.writer(csvFile)
        
        # Write header if file is empty
        if not os.path.isfile(csv_file_path) or os.stat(csv_file_path).st_size == 0:
            writer.writerow(["Id", "Name"])

        if Id not in existing_ids:
            writer.writerow([Id, name])
            message.configure(text=f"✅ Images Saved for ID: {Id}, Name: {name}")
        else:
            message.configure(text=f"❌ ID {Id} already exists! Try another.")

def TrainImages():
    recognizer = cv2.face_LBPHFaceRecognizer.create()
    #recognizer = cv2.face.LBPHFaceRecognizer_create()
    # recognizer=cv2.createLBPHFaceRecognizer()
    # recognizer=cv2.face.EigenFaceRecognizer_create()
    harcascadePath = "haarcascade_frontalface_default.xml"
    detector = cv2.CascadeClassifier(harcascadePath)
    faces, Id = getImagesAndLabels("TrainingImage")
    recognizer.train(faces, np.array(Id))
    recognizer.save("TrainingImageLabel\Trainner.yml")
    res = "Image Trained"  # +",".join(str(f) for f in Id)
    message.configure(text=res)


def getImagesAndLabels(path):
    # get the path of all the files in the folder
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    # print(imagePaths)

    # create empth face list
    faces = []
    # create empty ID list
    Ids = []
    # now looping through all the image paths and loading the Ids and the images
    for imagePath in imagePaths:
        # loading the image and converting it to gray scale
        pilImage = Image.open(imagePath).convert('L')
        # Now we are converting the PIL image into numpy array
        imageNp = np.array(pilImage, 'uint8')
        # getting the Id from the image
        Id = int(os.path.split(imagePath)[-1].split(".")[1])
        # extract the face from the training image sample
        faces.append(imageNp)
        Ids.append(Id)
    return faces, Ids



def TrackImages():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read("TrainingImageLabel/Trainner.yml")  # Ensure this file exists

    harcascadePath = "haarcascade_frontalface_default.xml"
    faceCascade = cv2.CascadeClassifier(harcascadePath)

    # Load Employee Details CSV
    df = pd.read_csv("EmployeeDetails/EmployeeDetails.csv")

    # 🔍 Fix column names (strip spaces)
    df.columns = df.columns.str.strip()

    # 🔍 Ensure 'Id' and 'Name' columns exist
    if "Id" not in df.columns or "Name" not in df.columns:
        print("❌ Error: CSV does not have 'Id' or 'Name' columns!")
        print("CSV Columns:", df.columns.tolist())
        return

    # 🔍 Convert 'Id' column to string (if stored as int)
    df["Id"] = df["Id"].astype(str)

    # Setup Video Capture
    ipcam = "http://192.168.1.4:8080/video"  # Change to local cam if needed
    cam = cv2.VideoCapture(ipcam)

    font = cv2.FONT_HERSHEY_SIMPLEX
    col_names = ['Id', 'Name', 'Date', 'Time']
    attendance = pd.DataFrame(columns=col_names)

    # Ensure "ImagesUnknown" directory exists
    unknown_folder = "ImagesUnknown"
    if not os.path.exists(unknown_folder):
        os.makedirs(unknown_folder)

    while True:
        ret, im = cam.read()
        if not ret:
            print("Error: Cannot capture frame!")
            break

        gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(30, 30))

        for (x, y, w, h) in faces:
            cv2.rectangle(im, (x, y), (x+w, y+h), (225, 0, 0), 2)

            # Recognize the face
            Id, conf = recognizer.predict(gray[y:y+h, x:x+w])

            if conf < 90:  # If confidence is good
                ts = time.time()
                date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
                timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')

                # 🔍 Ensure ID is a string for matching
                Id = str(Id)
                matching_rows = df[df["Id"] == Id]

                if not matching_rows.empty:
                    aa = matching_rows["Name"].values[0]  # Fetch first matching name
                else:
                    aa = "Unknown"

                tt = f"{Id}-{aa}"
                attendance.loc[len(attendance)] = [Id, aa, date, timeStamp]

                # Play sound in separate thread
                # threading.Thread(target=play_sound).start()

            else:
                Id = "Unknown"
                tt = "Unknown"
                
                # Save unknown face
                noOfFile = len(os.listdir(unknown_folder)) + 1
                unknown_path = os.path.join(unknown_folder, f"Unknown_{noOfFile}.jpg")
                cv2.imwrite(unknown_path, im[y:y+h, x:x+w])

            # Display the name
            cv2.putText(im, tt, (x, y - 10), font, 1, (0, 255, 0), 2)

        # Remove duplicate entries
        attendance = attendance.drop_duplicates(subset=['Id'], keep='first')

        cv2.imshow('Face Recognition', im)

        if cv2.waitKey(1) == ord('q'):  # Press 'q' to exit
            break

    # Save attendance to CSV

    ts = time.time()
    date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
    timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
    Hour, Minute, Second = timeStamp.split(":")

    attendance_file = f"Attendance/Attendance_{date}_{Hour}-{Minute}-{Second}.csv"
    attendance.to_csv(attendance_file, index=False)

    cam.release()
    cv2.destroyAllWindows()

    # ✅ Print ID, Name, Date, and Time instead of "Attendance saved successfully!"
    for index, row in attendance.iterrows():
        # print(f"✅ Attendance Recorded: ID={row['Id']}, Name={row['Name']}, Date={row['Date']}, Time={row['Time']}")
        # message2.configure(text="Attendance saved successfully!")
        message2.configure(text=f"✅ ID={row['Id']}, Name={row['Name']}, Date={row['Date']}, Time={row['Time']}")




clearButton = tk.Button(window, text="Clear", command=clear, fg="red", bg="yellow",
                        width=20, height=2, activebackground="Red", font=('times', 15, ' bold '))
clearButton.place(x=950, y=200)
clearButton2 = tk.Button(window, text="Clear", command=clear2, fg="red", bg="yellow",
                         width=20, height=2, activebackground="Red", font=('times', 15, ' bold '))
clearButton2.place(x=950, y=300)
takeImg = tk.Button(window, text="Take Images", command=TakeImages, fg="red", bg="yellow",
                    width=20, height=3, activebackground="Red", font=('times', 15, ' bold '))
takeImg.place(x=200, y=500)
trainImg = tk.Button(window, text="Train Images", command=TrainImages, fg="red",
                     bg="yellow", width=20, height=3, activebackground="Red", font=('times', 15, ' bold '))
trainImg.place(x=500, y=500)
trackImg = tk.Button(window, text="Track Images", command=TrackImages, fg="red",
                     bg="yellow", width=20, height=3, activebackground="Red", font=('times', 15, ' bold '))
trackImg.place(x=800, y=500)
quitWindow = tk.Button(window, text="Quit", command=quit, fg="red", bg="yellow",
                       width=20, height=3, activebackground="Red", font=('times', 15, ' bold '))
quitWindow.place(x=1100, y=500)


window.mainloop()
